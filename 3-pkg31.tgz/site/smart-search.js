import { BACKEND_URL, EXTERNAL_AI } from './rag-config.js';
import { $, el, startTurn, typeInto, wireComposer, NOTICE } from './chat-ui.js';
let tools, pipeline;
import { buildIndex, search } from './tool-search.js';
let index;
const load = async () => tools || (tools = await (await fetch('./search-tools.json')).json());
const getIndex = items => index || (index = buildIndex(items));
function card(t, i, extra) {
  const c = el('article', null, 'src-card fade'); c.style.animationDelay = (i * 0.12) + 's';
  c.append(el('strong', t.name));
  for (const [label, txt] of extra || []) { const p = el('p', null, 'tool-line'); p.append(el('b', label + ' '), document.createTextNode(txt)); c.append(p); }
  c.append(el('small', t.description));
  const a = el('a', 'افتح الأداة ↗'); a.href = t.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; a.dataset.osintTool = t.name; c.append(a);
  if (window.OSINTTaskFile) c.append(' ', window.OSINTTaskFile.button(() => ({ name: t.name, url: t.url, type: 'unknown', from: 'البحث الذكي', note: 'أداة مقترحة من البحث الذكي التجريبي. لم تُراجع بعد.' })));
  return c;
}
async function semantic(q, cands) {
  if (!pipeline) { const mod = await import('https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/+esm'); pipeline = await mod.pipeline('feature-extraction', 'Xenova/paraphrase-multilingual-MiniLM-L12-v2', { dtype: 'q8' }); }
  const vs = []; for (const s of [q, ...cands.map(x => `${x.t.name}: ${x.t.description}`)]) vs.push((await pipeline(s, { pooling: 'mean', normalize: true })).data);
  return cands.map((c, i) => ({ ...c, sem: vs[0].reduce((s, v, k) => s + v * vs[i + 1][k], 0) })).sort((a, b) => b.sem - a.sem);
}
let last = null;
async function ask(q) {
  $('greet').hidden = true; const body = startTurn($('thread'), q);
  const all = await load(), found = search(getIndex(all), q), cands = found.confident ? found.candidates : []; last = { q, cands };
  body.replaceChildren(); const title = el('h3', null, 'answer-title'); body.append(title);
  if (!cands.length) { await typeInto(title, 'لا أجد أداة مناسبة لهذا الطلب في الدليل بثقة كافية. جرّب وصف المهمة بكلمات أخرى (مثل: صورة، سفينة، نطاق، تسريب)، أو تصفّح خريطة الأدوات.'); return; }
  let picks = null, web = [];
  if (EXTERNAL_AI && BACKEND_URL) {
    try { const r = await fetch(BACKEND_URL, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ mode: 'recommend', query: q, candidates: cands.map(x => ({ id: x.id, name: x.t.name, description: x.t.description })) }) }); if (r.ok) { const j = await r.json(); picks = j.picks; web = Array.isArray(j.web) ? j.web : []; } } catch { /* keyword fallback */ }
  }
  if (Array.isArray(picks) && picks.length) {
    await typeInto(title, 'هذه أنسب الأدوات في الدليل لسؤالك:');
    picks.forEach((k, i) => { const t = all[k.id]; if (t) body.append(card(t, i, [['لماذا هذه الأداة؟', k.why], ['كيف تستخدمها؟', k.how]])); });
    body.append(el('p', 'الترشيح من أدوات الدليل فقط، والروابط من قاعدة الدليل نفسها. افحص كل أداة ومصدرها قبل الاعتماد عليها.', 'meta-line fade'));
  } else {
    await typeInto(title, EXTERNAL_AI ? 'تعذّر الترشيح الآن، وهذه أقرب الأدوات بالكلمات:' : 'أقرب الأدوات بالكلمات:');
    cands.slice(0, 8).forEach((x, i) => body.append(card(x.t, i)));
  }
  const okWeb = web.filter(x => /^https:\/\//.test(x.url || '')).slice(0, 3);
  if (okWeb.length) {
    const box = el('div', null, 'web-results'); box.append(el('h4', 'نتائج بحث ويب خارجية (غير مفحوصة)', 'why'));
    okWeb.forEach(x => { const a = el('a', x.title || x.host); a.href = x.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; const d = el('div', null, 'web-item'); d.append(a, el('small', ' ' + x.host, 'url')); box.append(d); });
    box.append(el('p', 'هذه روابط من بحث عام على الويب وليست من قاعدة الدليل، ولم تُفحص. افتحها وتحقق منها بنفسك.', 'meta-line fade')); body.append(box);
  }
}
wireComposer({ form: $('composer'), input: $('q'), send: $('send'), chips: [...document.querySelectorAll('.chip')], onAsk: async q => { try { await ask(q); } catch (e) { startTurn($('thread'), q).replaceChildren(el('p', 'تعذّر إكمال الطلب: ' + e.message, 'why')); } } });
$('local').onclick = async () => {
  if (!last) { $('status').textContent = 'اسأل أولًا ثم رتّب النتائج.'; return; }
  $('status').textContent = 'جارٍ تنزيل نموذج صغير يعمل على جهازك (مرة واحدة)...';
  try { const r = await semantic(last.q, last.cands), body = startTurn($('thread'), 'ترتيب دلالي على جهازي'); body.replaceChildren(el('h3', 'ترتيب دلالي تجريبي من نموذج يعمل على جهازك:', 'answer-title')); r.slice(0, 6).forEach((x, i) => body.append(card(x.t, i))); $('status').textContent = ''; }
  catch (e) { $('status').textContent = 'تعذر تشغيل النموذج على هذا الجهاز: ' + e.message; }
};
if (EXTERNAL_AI) $('notice').textContent = NOTICE;

const initQ = new URLSearchParams(location.search).get('q');
if (initQ && initQ.trim()) { const q = initQ.trim().slice(0, 300); $('q').value = q; ask(q).catch(e => startTurn($('thread'), q).replaceChildren(el('p', 'تعذّر إكمال الطلب: ' + e.message, 'why'))); }
